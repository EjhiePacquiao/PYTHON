import os
import io
import json
import base64
from datetime import datetime
from flask import Flask, render_template, request, jsonify, send_from_directory, url_for, session, redirect
from werkzeug.security import generate_password_hash, check_password_hash
from PIL import Image
import qrcode

BASE = os.path.abspath(os.path.dirname(__file__))
STORAGE = os.path.join(BASE, 'storage')
PHOTOS = os.path.join(STORAGE, 'photos')
QRCODES = os.path.join(STORAGE, 'qrcodes')
DB_DIR = os.path.join(STORAGE, 'db')
STUDENTS_JSON = os.path.join(DB_DIR, 'students.json')
ATT_JSON = os.path.join(DB_DIR, 'attendance.json')
USERS_JSON = os.path.join(DB_DIR, 'users.json')
USERS_PLAIN_JSON = os.path.join(DB_DIR, 'users_plain.json')

for d in (STORAGE, PHOTOS, QRCODES, DB_DIR):
    os.makedirs(d, exist_ok=True)


def read_json(path):
    if not os.path.exists(path):
        return []
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def write_json(path, data):
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


app = Flask(__name__, static_folder='static', template_folder='templates')
app.secret_key = 'your-secret-key-change-this-in-production'


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        data = request.json
        email = data.get('email')
        password = data.get('password')

        users = read_json(USERS_JSON)
        user = next((u for u in users if u.get('email') == email), None)

        if user and check_password_hash(user.get('password'), password):
            session['user_id'] = user.get('id')
            session['email'] = user.get('email')
            return jsonify({'ok': True, 'message': 'Login successful'})
        else:
            return jsonify({'ok': False, 'message': 'Invalid email or password'}), 401

    return render_template('login.html')


@app.route('/register_page')
def register_page():
    return render_template('register.html')


@app.route('/register', methods=['POST'])
def register():
    data = request.json
    email = data.get('email')
    password = data.get('password')

    if not email or not password:
        return jsonify({'ok': False, 'message': 'Email and password required'}), 400

    users = read_json(USERS_JSON)
    users_plain = read_json(USERS_PLAIN_JSON)

    if any(u.get('email') == email for u in users):
        return jsonify({'ok': False, 'message': 'Email already exists'}), 400

    user_id = max([u['id'] for u in users], default=0) + 1

    new_user = {
        'id': user_id,
        'email': email,
        'password': generate_password_hash(password)
    }

    plain_user = {
        'id': user_id,
        'email': email,
        'plain_password': password
    }

    users.append(new_user)
    users_plain.append(plain_user)
    write_json(USERS_JSON, users)
    write_json(USERS_PLAIN_JSON, users_plain)

    return jsonify({'ok': True, 'message': 'Registration successful'})


@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')


@app.route('/admin')
def admin():
    if 'user_id' not in session:
        return redirect('/login')
    return render_template('admin.html')


@app.route('/student')
def student_page():
    if 'user_id' not in session:
        return redirect('/login')
    return render_template('student.html')


@app.route('/attendance')
def attendance_page():
    if 'user_id' not in session:
        return redirect('/login')
    return render_template('attendance.html')

# User Management APIs


@app.route('/api/users/full', methods=['GET'])
def api_users_full():
    """Returns users with plain passwords for admin viewing"""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401

    users = read_json(USERS_JSON)
    users_plain = read_json(USERS_PLAIN_JSON)

    result = []
    for user in users:
        plain_data = next(
            (p for p in users_plain if p['id'] == user['id']), None)
        result.append({
            'id': user['id'],
            'email': user['email'],
            'plain_password': plain_data['plain_password'] if plain_data else None
        })

    return jsonify(result)


@app.route('/api/users', methods=['GET', 'POST'])
def api_users():
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401

    users = read_json(USERS_JSON)
    users_plain = read_json(USERS_PLAIN_JSON)

    if request.method == 'GET':
        safe_users = [{'id': u['id'], 'email': u['email']} for u in users]
        return jsonify(safe_users)
    else:
        payload = request.json or {}
        user_id = payload.get('id')
        email = payload.get('email')
        password = payload.get('password')

        if not email:
            return jsonify({'error': 'Email required'}), 400

        if user_id:
            user = next((u for u in users if u.get('id') == user_id), None)
            plain_user = next(
                (u for u in users_plain if u.get('id') == user_id), None)

            if user:
                user['email'] = email
                if plain_user:
                    plain_user['email'] = email

                if password:
                    user['password'] = generate_password_hash(password)
                    if plain_user:
                        plain_user['plain_password'] = password
        else:
            if not password:
                return jsonify({'error': 'Password required for new user'}), 400

            if any(u.get('email') == email for u in users):
                return jsonify({'error': 'Email already exists'}), 400

            user_id = max([u['id'] for u in users], default=0) + 1

            new_user = {
                'id': user_id,
                'email': email,
                'password': generate_password_hash(password)
            }
            users.append(new_user)

            plain_user = {
                'id': user_id,
                'email': email,
                'plain_password': password
            }
            users_plain.append(plain_user)

        write_json(USERS_JSON, users)
        write_json(USERS_PLAIN_JSON, users_plain)
        return jsonify({'ok': True})


@app.route('/api/users/<int:user_id>', methods=['DELETE'])
def delete_user(user_id):
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401

    users = read_json(USERS_JSON)
    users_plain = read_json(USERS_PLAIN_JSON)

    users = [u for u in users if u.get('id') != user_id]
    users_plain = [u for u in users_plain if u.get('id') != user_id]

    write_json(USERS_JSON, users)
    write_json(USERS_PLAIN_JSON, users_plain)

    return jsonify({'ok': True})

# Student APIs


@app.route('/api/students', methods=['GET', 'POST'])
def api_students():
    students = read_json(STUDENTS_JSON)
    if request.method == 'GET':
        students_sorted = sorted(
            students, key=lambda s: s.get('lastname', '').lower())
        return jsonify(students_sorted)
    else:
        payload = request.json or {}
        idno = payload.get('idno')
        if not idno:
            return jsonify({'error': 'idno required'}), 400
        existing = next((s for s in students if s.get('idno') == idno), None)
        if existing:
            existing.update(payload)
        else:
            students.append(payload)
        write_json(STUDENTS_JSON, students)
        return jsonify({'ok': True, 'student': payload})


@app.route('/api/students/<idno>', methods=['DELETE'])
def delete_student(idno):
    students = read_json(STUDENTS_JSON)
    students = [s for s in students if s.get('idno') != idno]
    write_json(STUDENTS_JSON, students)
    return jsonify({'ok': True})


@app.route('/api/upload_photo', methods=['POST'])
def api_upload_photo():
    payload = request.json or {}
    idno = payload.get('idno')
    data = payload.get('data')
    if not idno or not data:
        return jsonify({'error': 'idno & data required'}), 400
    if ',' in data:
        _, b64 = data.split(',', 1)
    else:
        b64 = data
    try:
        imgbytes = base64.b64decode(b64)
        img = Image.open(io.BytesIO(imgbytes)).convert('RGB')
        path = os.path.join(PHOTOS, f'{idno}.jpg')
        img.save(path, 'JPEG', quality=85)
        url = url_for('serve_photo', filename=f'{idno}.jpg')
        return jsonify({'ok': True, 'url': url})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/photos/<path:filename>')
def serve_photo(filename):
    return send_from_directory(PHOTOS, filename)


@app.route('/api/generate_qr', methods=['POST'])
def api_generate_qr():
    payload = request.json or {}
    idno = payload.get('idno')
    if not idno:
        return jsonify({'error': 'idno required'}), 400
    qr = qrcode.QRCode(box_size=6, border=2)
    qr.add_data(idno)
    qr.make(fit=True)
    img = qr.make_image(fill_color='black', back_color='white')
    path = os.path.join(QRCODES, f'{idno}.png')
    img.save(path)
    url = url_for('serve_qr', filename=f'{idno}.png')
    return jsonify({'ok': True, 'url': url})


@app.route('/qrcodes/<path:filename>')
def serve_qr(filename):
    return send_from_directory(QRCODES, filename)


@app.route('/api/attendance', methods=['GET', 'POST'])
def api_attendance():
    arr = read_json(ATT_JSON)
    if request.method == 'GET':
        dateq = request.args.get('date')
        if dateq:
            filtered = [a for a in arr if a.get('date') == dateq]
            return jsonify(filtered)
        return jsonify(arr)
    else:
        payload = request.json or {}
        idno = payload.get('idno')
        name = payload.get('name', '')
        course = payload.get('course', '')
        if not idno:
            return jsonify({'error': 'idno required'}), 400
        entry = {
            'id': f'{int(datetime.utcnow().timestamp()*1000)}',
            'idno': idno,
            'time': datetime.now().strftime('%H:%M:%S'),
            'date': datetime.now().strftime('%Y-%m-%d'),
            'name': name,
            'course': course
        }
        arr.append(entry)
        write_json(ATT_JSON, arr)
        return jsonify({'ok': True, 'entry': entry})


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
