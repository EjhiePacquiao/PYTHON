"""
Migrate existing users to support plain password viewing
Run this once: python migrate_users.py
"""
import json
import os

USERS_JSON = 'storage/db/users.json'
USERS_PLAIN_JSON = 'storage/db/users_plain.json'

print("=" * 50)
print("🔄 MIGRATING USERS")
print("=" * 50)

# Read existing users
if not os.path.exists(USERS_JSON):
    print("\n❌ No users.json found!")
    exit()

with open(USERS_JSON, 'r', encoding='utf-8') as f:
    users = json.load(f)

print(f"\n📊 Found {len(users)} user(s)")

# Create users_plain.json with placeholder passwords
users_plain = []
for user in users:
    users_plain.append({
        'id': user['id'],
        'email': user['email'],
        'plain_password': None  # Password unknown for existing users
    })
    print(f"  ✓ Migrated: {user['email']}")

# Save users_plain.json
with open(USERS_PLAIN_JSON, 'w', encoding='utf-8') as f:
    json.dump(users_plain, f, indent=2)

print(f"\n✅ Migration complete!")
print(f"📝 Created: {USERS_PLAIN_JSON}")
print("\n⚠️  NOTE: Passwords for existing users will show as 'Unknown'")
print("   They can still login with their original password.")
print("   To set a viewable password, use the Edit button and update it.")
print("=" * 50)
