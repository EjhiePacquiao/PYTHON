// static/js/app.js - client logic for scanner, student CRUD and attendance interaction
(async function () {
    function el(id) { return document.getElementById(id); }
    function centerNotify(text, ms = 3000) {
        const elc = el('centerNotify'); if (!elc) return;
        elc.textContent = text; elc.classList.add('show'); setTimeout(() => elc.classList.remove('show'), ms);
    }

    // --- Scanner on index.html ---
    if (el('video')) {
        const video = el('video'); const canvas = el('qr-canvas'); const ctx = canvas.getContext('2d');
        let stream = null;
        let isProcessing = false;

        async function start() {
            try {
                stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
                video.srcObject = stream;
                video.play();
                requestAnimationFrame(tick);
            } catch (e) {
                console.error(e);
                centerNotify('Camera access needed');
            }
        }
        function stop() { stream && stream.getTracks().forEach(t => t.stop()); }

        function showStudentPopup(student) {
            // Create popup element
            const popup = document.createElement('div');
            popup.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: white;
        padding: 24px;
        border-radius: 16px;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        z-index: 10000;
        min-width: 320px;
        text-align: center;
        animation: popupAppear 0.3s ease;
      `;

            popup.innerHTML = `
        <style>
          @keyframes popupAppear {
            from { opacity: 0; transform: translate(-50%, -50%) scale(0.8); }
            to { opacity: 1; transform: translate(-50%, -50%) scale(1); }
          }
        </style>
        <div style="width: 120px; height: 120px; margin: 0 auto 16px; border-radius: 50%; overflow: hidden; border: 4px solid #3b82f6; background: #f1f5f9;">
          ${student.photo_url
                    ? `<img src="${student.photo_url}" style="width: 100%; height: 100%; object-fit: cover;" />`
                    : `<div style="width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; font-size: 48px; color: #94a3b8;">👤</div>`
                }
        </div>
        <h2 style="margin: 0 0 8px 0; color: #0f172a; font-size: 20px;">${student.lastname}, ${student.firstname}</h2>
        <div style="background: #f8fafc; padding: 12px; border-radius: 8px; margin-top: 12px; text-align: left;">
          <p style="margin: 4px 0; color: #64748b; font-size: 14px;"><strong>ID No:</strong> ${student.idno}</p>
          <p style="margin: 4px 0; color: #64748b; font-size: 14px;"><strong>Course:</strong> ${student.course}</p>
          <p style="margin: 4px 0; color: #64748b; font-size: 14px;"><strong>Level:</strong> ${student.level}</p>
        </div>
        <div style="margin-top: 16px; padding: 12px; background: #10b981; color: white; border-radius: 8px; font-weight: 600;">
          ✓ Attendance Recorded
        </div>
      `;

            // Add backdrop
            const backdrop = document.createElement('div');
            backdrop.style.cssText = `
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.5);
        z-index: 9999;
        animation: fadeIn 0.3s ease;
      `;

            document.body.appendChild(backdrop);
            document.body.appendChild(popup);

            // Remove after 3 seconds
            setTimeout(() => {
                popup.style.animation = 'popupAppear 0.3s ease reverse';
                backdrop.style.animation = 'fadeIn 0.3s ease reverse';
                setTimeout(() => {
                    popup.remove();
                    backdrop.remove();
                    isProcessing = false;
                }, 300);
            }, 3000);
        }

        async function tick() {
            if (video.readyState === video.HAVE_ENOUGH_DATA && !isProcessing) {
                canvas.width = video.videoWidth;
                canvas.height = video.videoHeight;
                ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
                const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
                const code = jsQR(imageData.data, imageData.width, imageData.height);
                if (code) {
                    isProcessing = true;
                    const idno = code.data.trim();
                    try {
                        const res = await fetch('/api/students');
                        const students = await res.json();
                        const s = students.find(x => x.idno === idno);
                        if (s) {
                            await fetch('/api/attendance', {
                                method: 'POST',
                                headers: { 'content-type': 'application/json' },
                                body: JSON.stringify({
                                    idno: s.idno,
                                    name: s.lastname + ', ' + s.firstname,
                                    course: s.course + ' - ' + s.level
                                })
                            });
                            showStudentPopup(s);
                        } else {
                            centerNotify('Unknown ID: ' + idno, 2000);
                            isProcessing = false;
                        }
                    } catch (e) {
                        console.error(e);
                        centerNotify('Error saving attendance');
                        isProcessing = false;
                    }
                    return;
                }
            }
            requestAnimationFrame(tick);
        }
        start();
        window.addEventListener('pagehide', stop);
    }

    // --- Student page logic ---
    if (el('studentsTable') && !document.getElementById('btnSaveStudent')) {
        // This is for the old layout, skip if new layout exists
        const studentsTable = el('studentsTable');
        const studentModal = el('studentModal');
        let currentPhoto = null;
        let selectedStudentData = null;

        async function fetchStudents() {
            const res = await fetch('/api/students');
            return await res.json();
        }

        function renderTable(list) {
            if (list.length === 0) {
                studentsTable.innerHTML = '<tr><td colspan="7" style="text-align:center; color:#94a3b8;">No students yet</td></tr>';
                return;
            }

            studentsTable.innerHTML = list.map((s, i) => `
      <tr>
        <td>${i + 1}</td>
        <td>${s.idno}</td>
        <td>${s.lastname}</td>
        <td>${s.firstname}</td>
        <td>${s.course}</td>
        <td>${s.level}</td>
        <td>
          <button class="view" data-id="${s.idno}">👁️ View</button> 
          <button class="del" data-id="${s.idno}">🗑️ Delete</button>
        </td>
      </tr>`).join('');

            // Attach View button listeners
            document.querySelectorAll('.view').forEach(b => b.addEventListener('click', async e => {
                const id = e.currentTarget.dataset.id;
                const list = await fetchStudents();
                const s = list.find(x => x.idno === id);
                if (!s) return;

                // Display student info in middle panel
                selectedStudentData = s;
                el('displayIdno').textContent = s.idno;
                el('displayLastname').textContent = s.lastname;
                el('displayFirstname').textContent = s.firstname;
                el('displayCourse').textContent = s.course;
                el('displayLevel').textContent = s.level;

                if (s.photo_url) {
                    el('displayPhoto').src = s.photo_url;
                    el('displayPhoto').style.display = 'block';
                    el('displayPhotoPlaceholder').style.display = 'none';
                } else {
                    el('displayPhoto').style.display = 'none';
                    el('displayPhotoPlaceholder').style.display = 'block';
                }

                // Enable edit button
                el('btnEditStudent').disabled = false;

                centerNotify('Student loaded', 1200);
            }));

            // Attach Delete button listeners
            document.querySelectorAll('.del').forEach(b => b.addEventListener('click', async e => {
                const id = e.currentTarget.dataset.id;
                if (!confirm('Delete this student?')) return;

                centerNotify('Student deleted');
                setTimeout(() => location.reload(), 500);
            }));
        }

        // Load students on page load
        fetchStudents().then(students => renderTable(students));
    }

    // --- Attendance page ---
    if (el('attTable') && el('btnSearch')) {
        function render(entries) {
            if (entries.length === 0) {
                el('attTable').innerHTML = '<tr><td colspan="4" style="text-align:center; color:#94a3b8;">No attendance records for this date</td></tr>';
                return;
            }
            el('attTable').innerHTML = entries.map((r, i) => `
        <tr>
          <td>${i + 1}</td>
          <td>${r.time}</td>
          <td style="text-align:left">${r.name}</td>
          <td>${r.course}</td>
        </tr>`).join('');
        }

        const today = new Date().toISOString().slice(0, 10);
        if (el('searchDate')) el('searchDate').value = today;

        el('btnSearch').addEventListener('click', async () => {
            const d = el('searchDate').value || today;
            const res = await fetch('/api/attendance?date=' + d);
            const j = await res.json();
            render(j);
        });

        const res = await fetch('/api/attendance?date=' + (el('searchDate') ? el('searchDate').value : today));
        render(await res.json());
    }

})();